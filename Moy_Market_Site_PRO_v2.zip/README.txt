Мой Маркет — интернет-дүкөн
Дарек: Жибек-Жолу 235, Бишкек
WhatsApp для заказов: +996 507 66 88 66
GitHub Pages: https://moymarket235.github.io/moy-market/

Файлдар:
- index.html — негизги сайт
- style.css — дизайн
- script.js — каталог, издөө, категориялар, себет жана WhatsApp заказ
- logo.jpg — логотип
